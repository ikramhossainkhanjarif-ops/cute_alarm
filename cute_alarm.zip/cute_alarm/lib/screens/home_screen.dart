import 'package:flutter/material.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import '../models/alarm_model.dart';
import '../services/storage_services.dart';
import 'message_crud_screen.dart';
import 'alarm_ring_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  TimeOfDay _selectedTime = const TimeOfDay(hour: 7, minute: 0);
  bool _isAlarmSet = false;

  @override
  void initState() {
    super.initState();
    _loadAlarm();
  }

  Future<void> _loadAlarm() async {
    AlarmModel? alarm = await StorageService.getAlarm();
    if (alarm != null) {
      setState(() {
        _selectedTime = TimeOfDay(hour: alarm.hour, minute: alarm.minute);
        _isAlarmSet = alarm.isActive;
      });
    }
  }

  @pragma('vm:entry-point')
  static void alarmCallback() {
    print("Alarm fired!");
  }

  Future<void> _toggleAlarm() async {
    if (_isAlarmSet) {
      await AndroidAlarmManager.cancel(1);
      await StorageService.saveAlarm(AlarmModel(id: 1, hour: _selectedTime.hour, minute: _selectedTime.minute, isActive: false));
      setState(() => _isAlarmSet = false);
    } else {
      final now = DateTime.now();
      var alarmTime = DateTime(now.year, now.month, now.day, _selectedTime.hour, _selectedTime.minute);
      if (alarmTime.isBefore(now)) alarmTime = alarmTime.add(const Duration(days: 1));

      await AndroidAlarmManager.oneShotAt(alarmTime, 1, alarmCallback, exact: true, wakeup: true);
      await StorageService.saveAlarm(AlarmModel(id: 1, hour: _selectedTime.hour, minute: _selectedTime.minute, isActive: true));
      setState(() => _isAlarmSet = true);
      
      // Immediate Test Preview Trigger
      Navigator.push(context, MaterialPageRoute(builder: (_) => const AlarmRingScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF0F5),
      appBar: AppBar(
        title: const Text('💘 Love Alarm'),
        backgroundColor: Colors.pink[200],
        actions: [
          IconButton(icon: const Icon(Icons.edit_note), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MessageCrudScreen()))),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(_selectedTime.format(context), style: TextStyle(fontSize: 64, color: Colors.pink[700], fontWeight: FontWeight.w300)),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.pink[300]),
              onPressed: () async {
                final time = await showTimePicker(context: context, initialTime: _selectedTime);
                if (time != null) setState(() => _selectedTime = time);
              },
              child: const Text("Set Time", style: TextStyle(color: Colors.white)),
            ),
            const SizedBox(height: 40),
            IconButton(
              iconSize: 72,
              icon: Icon(Icons.power_settings_new, color: _isAlarmSet ? Colors.pink : Colors.grey),
              onPressed: _toggleAlarm,
            ),
            Text(_isAlarmSet ? "Alarm Active" : "Alarm Inactive", style: TextStyle(color: Colors.pink[400])),
          ],
        ),
      ),
    );
  }
}
