import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:intl/intl.dart';
import '../services/storage_services.dart';
import '../widgets/heart_animation.dart';

class AlarmRingScreen extends StatefulWidget {
  const AlarmRingScreen({Key? key}) : super(key: key);
  @override
  _AlarmRingScreenState createState() => _AlarmRingScreenState();
}

class _AlarmRingScreenState extends State<AlarmRingScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  String _romanticQuote = "শুভ সকাল Cutieee...";
  String _currentTime = "";

  @override
  void initState() {
    super.initState();
    _playAlarm();
    _loadMessage();
    _currentTime = DateFormat('hh:mm a\nEEEE, d MMMM').format(DateTime.now());
  }

  Future<void> _playAlarm() async {
    await _audioPlayer.setReleaseMode(ReleaseMode.loop);
    await _audioPlayer.play(AssetSource('sounds/alarm_sound.mp3'));
  }

  Future<void> _loadMessage() async {
    String msg = await StorageService.getRandomMessage();
    setState(() => _romanticQuote = msg);
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(image: AssetImage('assets/images/romantic_bg.jpg'), fit: BoxFit.cover),
            ),
          ),
          Container(color: Colors.black.withOpacity(0.3)),
          const HeartAnimation(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(_currentTime, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
                  Card(
                    color: Colors.white.withOpacity(0.85),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Text(_romanticQuote, textAlign: TextAlign.center, style: const TextStyle(color: Colors.pinkAccent, fontSize: 20, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.pinkAccent, padding: const EdgeInsets.symmetric(horizontal: 60, vertical: 16)),
                    onPressed: () {
                      _audioPlayer.stop();
                      Navigator.pop(context);
                    },
                    child: const Text("Dismiss", style: TextStyle(fontSize: 18, color: Colors.white)),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
